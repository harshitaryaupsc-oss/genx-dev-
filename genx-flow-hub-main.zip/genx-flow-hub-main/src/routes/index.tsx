import { createFileRoute } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "motion/react";
import { useRef, useState, useEffect } from "react";
import genxLogo from "@/assets/genx-logo-gold.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GenXdevelopers — India's Software Development Company" },
      { name: "description", content: "From billing software to mobile apps, secure websites, and financial tools — GenXdevelopers is your end-to-end software engineering partner." },
    ],
  }),
  component: Home,
});

const heroPills = [
  "Billing Software", "Mobile Apps", "Custom Websites", "Site Security", "Financial Tools", "Integrations",
];

const stats = [
  { value: "120+", label: "Clients Served" },
  { value: "30+", label: "Team Members" },
  { value: "8+", label: "Years Experience" },
  { value: "150+", label: "Projects Delivered" },
  { value: "3-6", label: "Months Support" },
];

const whyUs = [
  { title: "Fast Delivery", desc: "Streamlined sprints help you launch products quickly without compromising on quality or reliability." },
  { title: "Affordable Pricing", desc: "Premium-grade development at startup-friendly rates — built for Indian businesses scaling globally." },
  { title: "Complete Ownership", desc: "Source code, project assets and deployment — full ownership stays with you, always." },
  { title: "End-to-End Services", desc: "Design, development, branding, marketing and support — all under one unified roof." },
  { title: "Experienced Team", desc: "30+ engineers, designers, AI specialists and project managers ready to ship." },
  { title: "Trusted by Businesses", desc: "150+ projects delivered across fintech, e-commerce, healthcare and enterprise." },
];

const services = [
  { code: "01", title: "Billing & Transaction Software", desc: "Invoicing, POS, subscriptions and payment flows engineered to scale with your revenue.", tags: ["Stripe", "UPI", "Invoices", "POS"] },
  { code: "02", title: "Mobile App Development", desc: "Android and iOS apps built on modern, scalable architecture for every industry.", tags: ["Android", "iOS", "React Native", "Flutter"] },
  { code: "03", title: "Custom Website Development", desc: "Corporate, SaaS, portfolio and product sites designed for speed, SEO and growth.", tags: ["Responsive", "CMS", "SEO", "API"] },
  { code: "04", title: "Site Security & Hardening", desc: "Audits, WAF, RLS policies, secret hygiene and continuous monitoring for peace of mind.", tags: ["Audit", "WAF", "SSL", "Pen-test"] },
  { code: "05", title: "Financial Tools", desc: "Calculators, dashboards, reconciliation and reporting tailored to your books.", tags: ["FinOps", "BI", "Reports"] },
  { code: "06", title: "Custom Integrations", desc: "Stitch banks, ERPs and SaaS into a single source of truth via clean APIs.", tags: ["API", "ETL", "Webhooks"] },
];

const tech = ["React", "Next.js", "Node.js", "React Native", "Flutter", "Python", "Django", "PostgreSQL", "MongoDB", "TypeScript", "Firebase", "AWS", "Docker", "AI / LLMs", "REST APIs", "GraphQL"];

const process = [
  { n: "01", title: "Discovery Call", desc: "Free consultation to map your vision, goals and technical needs in detail." },
  { n: "02", title: "Scope & Quote", desc: "Detailed documentation and a transparent fixed-price or milestone quote." },
  { n: "03", title: "Design & Build", desc: "Agile sprints with weekly demos. You stay in the loop every step." },
  { n: "04", title: "Launch & Support", desc: "Smooth deployment with 3–6 months of post-launch support and maintenance." },
];

const testimonials = [
  { quote: "GenX built our entire billing stack — invoicing, UPI, subscriptions, admin panel. Delivered in 10 weeks, exactly as scoped.", name: "Rajesh K.", role: "Founder, PayLite" },
  { quote: "Our e-commerce store went live in 6 weeks with full payment integration and inventory. Outstanding quality for the price.", name: "Priya M.", role: "Co-founder, FreshMart" },
  { quote: "The financial dashboard they built replaced three tools we were paying for. They automated 80% of our reconciliation.", name: "Amit S.", role: "Director, SalesFlow" },
];

const industries = ["Fintech & Payments", "Healthcare & MedTech", "EdTech & E-Learning", "Logistics & Supply", "Real Estate & PropTech", "E-Commerce & Retail"];

function Home() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      <Nav />
      <Hero />
      <StatsBar />
      <WhyUs />
      <Services />
      <TechStack />
      <Process />
      <Testimonials />
      <Industries />
      <FinalCTA />
      <Footer />
    </div>
  );
}

function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all ${scrolled ? "bg-background/75 backdrop-blur-lg border-b border-border" : ""}`}>
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2 font-semibold tracking-tight">
          <img src={genxLogo.url} alt="GenXdevelopers" className="h-10 w-auto" />
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#about" className="hover:text-foreground transition">About</a>
          <a href="#services" className="hover:text-foreground transition">Services</a>
          <a href="#process" className="hover:text-foreground transition">Process</a>
          <a href="#industries" className="hover:text-foreground transition">Industries</a>
        </nav>
        <a href="#contact" className="rounded-full border border-primary/40 bg-primary/10 px-4 py-2 text-sm font-medium text-primary hover:bg-primary hover:text-primary-foreground transition">Contact Us</a>
      </div>
    </header>
  );
}

function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 120]);

  return (
    <section ref={heroRef} className="relative pt-28 md:pt-36 pb-20 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />

      <motion.div style={{ y }} className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        <div>
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-mono text-primary">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            🚀 India's Leading Software Development Company
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-6 text-4xl md:text-6xl lg:text-7xl font-semibold leading-[1.05] tracking-tight">
            We Write Code.<br />
            <span className="text-gradient">We Ship Products.</span><br />
            We Scale Businesses.
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6 max-w-xl text-base md:text-lg text-muted-foreground">
            From billing systems and mobile apps to secure websites and bespoke financial tools — GenXdevelopers is your end-to-end software engineering partner for India and beyond.
          </motion.p>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="mt-6 flex flex-wrap gap-2">
            {heroPills.map((p) => (
              <span key={p} className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface/60 px-3 py-1.5 text-xs text-foreground backdrop-blur">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                {p}
              </span>
            ))}
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-8 flex flex-wrap gap-3">
            <a href="#contact" className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:glow transition">
              Get Free Consultation
              <span className="transition group-hover:translate-x-1">→</span>
            </a>
            <a href="#services" className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/40 px-6 py-3 text-sm font-medium text-foreground backdrop-blur hover:bg-surface">
              Explore Services
            </a>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8 }} className="relative">
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-primary/20 via-accent/10 to-transparent blur-2xl" />
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-border shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&q=80"
              alt="GenXdevelopers engineering team building software"
              className="w-full h-full object-cover"
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-background/80 via-background/10 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 flex items-center gap-3 rounded-xl border border-border bg-background/70 backdrop-blur p-3">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-mono text-muted-foreground">deploy.production · all systems green</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}

function StatsBar() {
  return (
    <section className="relative border-y border-border bg-surface/30 backdrop-blur">
      <div className="mx-auto max-w-7xl px-6 py-10 grid grid-cols-2 md:grid-cols-5 gap-6">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="text-center md:text-left">
            <div className="text-3xl md:text-4xl font-semibold text-gradient">{s.value}</div>
            <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground font-mono">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function WhyUs() {
  return (
    <section id="about" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto">
          <div className="font-mono text-xs uppercase tracking-widest text-primary">/ Why Choose Us</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">Everything You Need,<br />Under One Roof</h2>
          <p className="mt-4 text-muted-foreground">From idea to launch and beyond — we're your long-term technology partner.</p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {whyUs.map((w, i) => (
            <motion.div
              key={w.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.05 }}
              className="group rounded-2xl border border-border bg-surface/40 p-6 backdrop-blur hover:border-primary/40 transition"
            >
              <div className="h-10 w-10 rounded-xl bg-primary/15 border border-primary/30 grid place-items-center text-primary font-mono text-sm">
                0{i + 1}
              </div>
              <h3 className="mt-5 text-lg font-semibold">{w.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{w.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="relative py-24 md:py-32 border-t border-border">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <div>
            <div className="font-mono text-xs uppercase tracking-widest text-primary">/ What We Build</div>
            <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">Full-Stack Software<br />Development Studio</h2>
          </div>
          <p className="max-w-md text-muted-foreground">From concept to deployment — we engineer solutions that drive real business outcomes.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((s, i) => <ServiceCard key={s.code} {...s} index={i} />)}
        </div>
      </div>
    </section>
  );
}

function ServiceCard({ code, title, desc, tags, index }: { code: string; title: string; desc: string; tags: string[]; index: number }) {
  const [pos, setPos] = useState({ x: 50, y: 50 });
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        setPos({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
      }}
      className="group relative overflow-hidden rounded-2xl border border-border bg-surface/40 p-8 backdrop-blur transition hover:border-primary/40"
    >
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
        style={{ background: `radial-gradient(circle 220px at ${pos.x}% ${pos.y}%, oklch(0.85 0.22 145 / 0.14), transparent)` }} />
      <div className="relative">
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs text-muted-foreground">{code}</span>
          <span className="h-1.5 w-1.5 rounded-full bg-primary opacity-60 group-hover:opacity-100" />
        </div>
        <h3 className="mt-6 text-xl font-semibold">{title}</h3>
        <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{desc}</p>
        <div className="mt-6 flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t} className="rounded-full border border-border bg-background/60 px-3 py-1 text-[11px] font-mono text-muted-foreground">{t}</span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function TechStack() {
  return (
    <section className="relative py-24 border-t border-border">
      <div className="mx-auto max-w-7xl px-6 text-center">
        <div className="font-mono text-xs uppercase tracking-widest text-primary">/ Our Tech Stack</div>
        <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">Built with Modern Technologies</h2>
        <p className="mt-4 text-muted-foreground max-w-xl mx-auto">We use the latest, most reliable tools to build products that last.</p>

        <div className="mt-12 flex flex-wrap justify-center gap-3">
          {tech.map((t, i) => (
            <motion.span
              key={t}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.03 }}
              className="rounded-xl border border-border bg-surface/50 px-4 py-2.5 text-sm font-mono text-foreground hover:border-primary/40 hover:text-primary transition"
            >
              {t}
            </motion.span>
          ))}
        </div>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section id="process" className="relative py-24 md:py-32 border-t border-border">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto">
          <div className="font-mono text-xs uppercase tracking-widest text-primary">/ Our Process</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">How We Deliver Your Product</h2>
          <p className="mt-4 text-muted-foreground">A transparent, milestone-driven process from the first call to final launch.</p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {process.map((p, i) => (
            <motion.div key={p.n} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
              className="relative rounded-2xl border border-border bg-surface/40 p-8 backdrop-blur">
              <div className="text-5xl font-semibold text-gradient/40 font-mono opacity-60">{p.n}</div>
              <h3 className="mt-4 text-lg font-semibold">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="relative py-24 md:py-32 border-t border-border">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto">
          <div className="font-mono text-xs uppercase tracking-widest text-primary">/ Client Stories</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">Trusted by Founders<br />Across India</h2>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <motion.div key={t.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
              className="rounded-2xl border border-border bg-surface/40 p-6 backdrop-blur">
              <div className="text-primary text-sm">★★★★★</div>
              <p className="mt-4 text-sm text-foreground leading-relaxed">"{t.quote}"</p>
              <div className="mt-6 flex items-center gap-3 pt-4 border-t border-border">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary to-accent grid place-items-center text-primary-foreground font-semibold text-sm">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Industries() {
  return (
    <section id="industries" className="relative py-24 md:py-32 border-t border-border">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center max-w-2xl mx-auto">
          <div className="font-mono text-xs uppercase tracking-widest text-primary">/ Industries</div>
          <h2 className="mt-3 text-4xl md:text-5xl font-semibold tracking-tight">We Build For Every Industry</h2>
          <p className="mt-4 text-muted-foreground">From healthcare to fintech — our engineers have shipped products across every major sector.</p>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-3 gap-4">
          {industries.map((ind, i) => (
            <motion.div key={ind} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
              className="group rounded-2xl border border-border bg-surface/40 p-6 backdrop-blur hover:border-primary/40 hover:bg-surface/60 transition cursor-default">
              <div className="flex items-center justify-between">
                <span className="text-sm md:text-base font-semibold">{ind}</span>
                <span className="text-primary opacity-0 group-hover:opacity-100 transition">→</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="relative py-24 md:py-32 border-t border-border">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <motion.h2 initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-4xl md:text-6xl font-semibold tracking-tight">
          Ready to Build Your<br /><span className="text-gradient">Next Big Idea?</span>
        </motion.h2>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">From idea validation to product launch — let's turn your vision into reality.</p>

        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }}
          className="mt-12 mx-auto max-w-xl flex flex-col sm:flex-row gap-3 p-2 rounded-full border border-border bg-surface/60 backdrop-blur">
          <input type="email" required placeholder="you@company.com"
            className="flex-1 bg-transparent px-5 py-3 text-sm outline-none placeholder:text-muted-foreground" />
          <button type="submit" className="rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:glow transition">
            {sent ? "Thanks — talk soon ✓" : "Get Free Consultation"}
          </button>
        </form>

        <div className="mt-6 text-sm text-muted-foreground">
          or call <a href="tel:+919992562964" className="text-primary hover:underline">+91 9992562964</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto max-w-7xl px-6 grid md:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2 font-semibold">
            <span className="grid place-items-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-mono text-sm">G</span>
            GenXdevelopers
          </div>
          <p className="mt-3 text-sm text-muted-foreground max-w-xs">Software, apps & financial tools — shipped on time, owned by you.</p>
        </div>
        <div>
          <div className="text-xs font-mono uppercase tracking-widest text-primary">Office</div>
          <p className="mt-3 text-sm text-muted-foreground">Tower 2, Okhla<br />Delhi, India</p>
        </div>
        <div>
          <div className="text-xs font-mono uppercase tracking-widest text-primary">Get in touch</div>
          <a href="tel:+919992562964" className="mt-3 block text-sm text-foreground hover:text-primary">+91 9992562964</a>
          <a href="#contact" className="mt-1 block text-sm text-muted-foreground hover:text-primary">Start a project →</a>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-6 mt-10 pt-6 border-t border-border text-xs text-muted-foreground font-mono flex flex-col md:flex-row gap-2 justify-between">
        <div>© {new Date().getFullYear()} GenXdevelopers. All rights reserved.</div>
        <div>India's Software Development Company</div>
      </div>
    </footer>
  );
}
